nomer = {10,20,20,30,40,50,50,60}

unik = set(list(nomer))
print(nomer)

# Saifulloh Fattah Bintoro_2408256_RPL1B