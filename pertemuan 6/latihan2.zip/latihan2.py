bilangan = int(input("masukan bilangan :"))

if bilangan > 0 : 
    print("bilangan adalah positif!")
    if bilangan % 2 == 0: 
        print("bilangan adalah genap")
    else: print("bilangan adalah ganjil")

if bilangan < 0 :
    print("bilangan adalah negatif")
    if bilangan % 2 == 0: 
        print("bilangan adalah genap")
    else: print("bilangan adalah ganjil")

elif bilangan == 0 :
        print("angka yang dimasukan adalah 0")
# Saifulloh Fattah Bintoro_2408256